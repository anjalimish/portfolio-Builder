<?php
$conn=mysqli_connect("localhost","root","","resume_builder");
?>